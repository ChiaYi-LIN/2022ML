1. 將 data 下載好放在 ./libriphone/ 中
2. 執行 python3 ML2022_HW2_rnn.py