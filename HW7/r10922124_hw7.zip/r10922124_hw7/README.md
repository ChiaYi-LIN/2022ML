# Training
```shell
python preprocess.py
bash train.sh
```

# Predicting
```shell
postprocess.py
```

# Reference
https://github.com/huggingface/transformers/tree/main/examples/pytorch/question-answering