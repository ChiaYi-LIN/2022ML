# Training
train three models seperatly with random seed 326, 1121 and 1121326
```python
python hw04.py
```

# Predicting
ensemble three models to get final predictions
```python
python test_ensemble.py
```