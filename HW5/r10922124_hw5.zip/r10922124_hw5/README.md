# Code
```python
python hw05.py
```

# Report
r10922124_hw5_report.pdf